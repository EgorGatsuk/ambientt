# AMBIENT — stage 5: Effects Engine

## Реализовано
- Reverb: convolution reverb с импульсным откликом 5.5 секунды; регулятор управляет уровнем эффекта.
- Delay: feedback delay с временем 120–800 мс и ограниченной обратной связью.
- Texture: waveshaper saturation с oversampling 4x.
- Modulation: низкочастотная модуляция высоты (vibrato) с глубиной до 18 cents.
- Параллельная маршрутизация dry + FX sends.
- Parameter Volume регулирует выходной уровень выбранного FX-блока (Reverb / Delay / Texture / Modulation).

## Запуск
Из корневой папки проекта:
```powershell
py -m http.server 8000
```
Откройте `http://localhost:8000`.

## Проверка
1. Сначала установите Reverb = 0, Delay = 0, Texture = 0, Modulation = 0. Сухой сигнал должен звучать.
2. Поднимайте Reverb: должен появиться пространственный хвост.
3. Поднимайте Delay: должны появиться повторения; при высоких значениях следите за накоплением обратной связи.
4. Поднимайте Texture: тембр должен становиться насыщеннее и жёстче.
5. Поднимайте Modulation: должна появиться периодическая высотная модуляция (vibrato).
6. Выберите эффект в Parameter Volume и меняйте его уровень: должен меняться только выход выбранного FX-блока.
7. Установите Master Volume в 0: на выходе должна быть тишина.

## Важные замечания
- Parameter Volume — пост-уровень выбранного эффекта, а не уровень send до эффекта.
- Reverb использует процедурно сгенерированный импульсный отклик; он не загружает внешние IR.
- Delay — макроконтроль: одновременно меняет время задержки, обратную связь и wet level.
- Modulation реализована как vibrato через oscillator detune; это не chorus/flanger.
- Texture реализована как waveshaper saturation; дополнительные шумовые/биткраш-компоненты не включены.
- MIDI input и 16-голосная полифония сохранены.

## Stage 5.1 — Independent FX Gain

The Parameter Volume control now stores an independent gain value for each effect:
- Reverb
- Delay
- Texture
- Modulation

Range: 0–200%. 100% is unity gain, 0% mutes that effect return, and 200% is +6.02 dB.
Changing the selected effect loads its own saved value; it does not overwrite other effects.
Gain is applied to the individual effect return, after the effect processor.

Note: boosting effect returns can increase the total mix level and cause clipping. Reduce Master Volume if necessary.

## Stage 5.2 — Double-click reset for FX Gain

Double-click the Parameter Volume knob to reset the currently selected effect's independent output gain to 100% (unity gain). Only the selected effect is reset; the other FX gain values remain unchanged.


## Stage 5.5 — Resonance response and physical-unit readouts

- Resonance filter cutoff moved from 12 kHz to 4 kHz.
- Resonance uses a nonlinear Q response: Q = 0.5 + 23.5 × (value / 100)^2.
- Pitch readout is shown in Hz for the most recently played MIDI/onscreen note. When no note has been played yet, it shows the transposed A4 reference frequency.
- Resonance readout is shown as filter Q (dimensionless), not Hz. The knob's internal control range remains 0–100.
- Other parameter displays and effect Gain behavior are unchanged.

Note: a pure sine wave contains no upper harmonics for a low-pass resonance peak to emphasize, so resonance may remain less audible on the Sine waveform than on Saw or Square. High Q settings can produce strong peaks; test at a conservative master level.


## Stage 6.1 — MIDI Learn

- Added a MIDI Learn panel to the MIDI Input section.
- Select a destination parameter, press MIDI Learn, then move one physical controller knob/slider.
- The first incoming Control Change message is assigned to the selected parameter.
- Assignments are stored in browser localStorage and survive page reloads in the same browser profile.
- One MIDI source (channel + CC number) controls one parameter; one parameter has one source. Reassigning a parameter replaces its previous source.
- Supported destinations: Pitch, Resonance, Texture, Attack, Sustain, Release, Reverb, Delay, Modulation, selected FX Gain, and Master Volume.
- CC values 0–127 are scaled to each destination's range. The selected FX Gain maps to 0–200%; other destinations map to 0–100%.
- Individual mappings can be removed, or all mappings cleared.

Limitations for this first pass:
- MIDI Learn captures the next CC message from the currently selected MIDI input; avoid touching unrelated controls while learning.
- No pickup/soft-takeover mode yet. A physical control may cause the destination to jump to the controller's current position on the first movement. This is intentionally deferred to the next substage.


## Stage 6.2 — Live output waveform and keyboard removal

- Added a Web Audio AnalyserNode after the master gain and before the audio output.
- The oscillator display now draws the actual post-effects, post-master time-domain output signal, not a static illustration of the selected oscillator.
- The display responds to played MIDI notes, oscillator waveform, pitch, envelope, and audible effect processing. Reverb and delay tails remain visible after note release when present in the output.
- When the engine has not started, the display shows only the center reference line.
- Removed the on-screen piano keyboard, its pointer handlers, and the computer-keyboard note-entry emulation that depended on the visual keys.
- Physical MIDI note input, MIDI Learn, stored CC assignments, and all sound controls remain in place.

Technical note: changing an effect while no note or effect tail is sounding cannot create a meaningful output waveform change. The analyser visualizes the actual output signal rather than inventing activity when the audio engine is silent.


## Stage 6.3 — Noise source and Pitch fine tuning

- Replaced Resonance with a dedicated White Noise source (0–100%).
- Noise is generated from a looping buffer per active voice, passes through the voice filter and envelope, and is mixed with the oscillator signal.
- Noise has its own independent Parameter Volume destination (0–200%) and is available in MIDI Learn.
- Existing saved MIDI mappings that targeted Resonance are migrated to Noise.
- Pitch is now fine tuning relative to each incoming MIDI note: 0–100% maps to -100..+100 cents, with 50% as zero offset.
- Pitch readout reports the resulting frequency in Hz for the most recently played MIDI note.
- The Pitch knob no longer transposes by +/-24 semitones.

Test guidance:
- At Pitch = 50%, MIDI notes play at standard equal-tempered pitch.
- At Pitch = 0%, the note is lowered by 100 cents; at 100%, raised by 100 cents.
- Noise at 0% adds no noise; increasing it blends white noise into each played note.


## Stage 6.3.1 — Audio playback regression fix

- Fixed a stale Resonance filter call in `noteOn()` that referenced the removed `resonanceToQ()` method and `this.resonance`, causing note creation to throw before audio sources started.
- Removed the obsolete per-voice low-pass filter from the signal path. Oscillator and Noise now mix directly into the envelope, consistent with Resonance having been replaced by Noise.
- Noise source is now stopped together with the oscillator on note release, voice stealing, and panic, preventing looping buffer sources from remaining active.
- JavaScript syntax checks pass. Browser playback still needs confirmation on the user's machine.


## Stage 6.4 — MIDI Soft Takeover

- Added pickup/soft-takeover behavior to saved MIDI CC mappings.
- After learning or reloading a mapping, the physical controller does not immediately overwrite the current software value.
- The mapping becomes active only when the incoming CC reaches or crosses the current parameter position (with a one-CC-step tolerance).
- Until pickup occurs, the MIDI status line instructs the user to move the physical control toward the current value.
- Once pickup occurs, the controller continuously controls the destination as before.
- The behavior applies to knobs, envelope sliders, selected FX Gain, and Master Volume.
- Removing or clearing mappings also clears their pickup state.
- JavaScript syntax checks pass; hardware behavior requires confirmation with the Korg controller.

## Stage 6.5 — Advanced MIDI Mapping

- A single physical CC source can control multiple destinations; multiple sources can control the same destination.
- Each destination mapping has its own Soft Takeover state.
- Each mapping supports an independent Min/Max range and optional inversion.
- Legacy Stage 6.4 mappings are migrated automatically to the expanded format.
- The MIDI panel displays incoming channel, CC number, value, and the number of mappings on that source.
- The assigned-mappings list can be collapsed and expanded. Its visibility preference is saved in localStorage; hiding the list does not disable MIDI assignments or MIDI Learn.
- Individual mappings can be removed independently; Clear removes all mappings.
- FX Gain supports a 0–200 range; other destinations use 0–100.

Test guidance:
1. Learn two different destinations from the same physical CC; both should respond after each destination's Soft Takeover pickup.
2. Learn two different physical CC sources for the same destination; either source should control it after pickup.
3. Set a restricted Min/Max range and verify the destination stays inside it.
4. Enable INV and verify the direction is reversed.
5. Collapse the mapping list, reload the page, and verify the list remains hidden while MIDI control continues to work.


## Stage 6.5.1 — MIDI CC response refinement

- Incoming Control Change messages are dispatched independently before note handling; held Note On events do not gate CC processing.
- Soft Takeover pickup tolerance increased from 1 to 6 MIDI steps (out of 127), reducing the amount of physical knob travel needed to acquire a parameter while retaining anti-jump behavior.
- Existing MIDI mappings and stored settings remain compatible.

## Granular Engine (первый этап)

В отдельной панели GRANULAR ENGINE можно загрузить локальный аудиофайл, выбрать рабочий участок waveform и использовать два режима:

- **CONTINUOUS** — непрерывный поток гранул; запуск и остановка кнопкой.
- **MIDI TRIGGER** — MIDI Note On запускает гранулярный голос, Note Off прекращает создание новых гранул для этой ноты.

Доступны Grain Size, Density, Position, Spray, Pitch, Pitch Random, Envelope, Stereo Spread, Level, Jitter, Reverse и Freeze Position. Звук направляется в существующие dry, reverb, delay и texture шины. Поддерживаемые форматы зависят от декодеров Web Audio в Electron/Chromium; WAV обычно наиболее надёжен.

Это первая реализация гранулярного движка. Перед сценическим использованием необходимо проверить декодирование конкретных файлов, MIDI-поведение, нагрузку CPU и стабильность на целевой Windows-системе.
