import { cp, mkdir, rm } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
const root = process.cwd();
const out = resolve(root, 'android/app/src/main/assets/www');
await rm(out, { recursive: true, force: true });
await mkdir(out, { recursive: true });
for (const item of ['index.html','css','js','presets']) await cp(resolve(root,item), resolve(out,item), {recursive:true});
const fontRoot = resolve(root,'node_modules/@fontsource');
if (existsSync(fontRoot)) {
  await mkdir(resolve(out,'fonts'),{recursive:true});
  const map = [
    ['manrope','400.css','manrope-400.css'],['manrope','500.css','manrope-500.css'],['manrope','600.css','manrope-600.css'],['manrope','700.css','manrope-700.css'],
    ['ibm-plex-mono','400.css','ibm-plex-mono-400.css'],['ibm-plex-mono','500.css','ibm-plex-mono-500.css']
  ];
  for (const [family,file,target] of map) {
    const src=resolve(fontRoot,family,file);
    if (existsSync(src)) await cp(src,resolve(out,'fonts',target));
  }
  for (const family of ['manrope','ibm-plex-mono']) {
    const dir=resolve(fontRoot,family,'files');
    if (existsSync(dir)) await cp(dir,resolve(out,'fonts',family),{recursive:true});
  }
}
console.log('Android Web assets synced.');
