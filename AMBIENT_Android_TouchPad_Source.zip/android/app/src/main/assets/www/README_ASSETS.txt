Run the asset sync script from project root to populate this folder.
