import { AmbientAudioEngine } from "./audio/audio-engine.js";
import { AmbientMidiEngine } from "./midi/midi-engine.js";
import { AmbientGranularEngine } from "./audio/granular-engine.js";

const audio = new AmbientAudioEngine();
const granular = new AmbientGranularEngine(audio);

const midi = new AmbientMidiEngine(audio, {
  onStatus: (message, state) => {
    document.getElementById("midiStatus").textContent = message;
    document.getElementById("midiLed").classList.toggle("on", state === "connected" || state === "activity");
    document.getElementById("midiConnect").textContent = state === "connected" ? "ОТКЛЮЧИТЬ" : "ПОДКЛЮЧИТЬ";
    if (state !== "connected" && midiLearnTarget) {
      midiLearnTarget = null;
      const learnButton = document.getElementById("midiLearnButton");
      if (learnButton) {
        learnButton.classList.remove("learning");
        learnButton.textContent = "MIDI LEARN";
      }
    }
  },
  onDevices: devices => {
    const select = document.getElementById("midiDevice");
    const previous = select.value;
    select.innerHTML = '<option value="">ВЫБЕРИТЕ MIDI INPUT</option>';
    devices.forEach(device => {
      const option = document.createElement("option");
      option.value = device.id;
      option.textContent = device.manufacturer
        ? `${device.manufacturer} / ${device.name}`
        : device.name;
      select.appendChild(option);
    });
    if (devices.some(device => device.id === previous)) select.value = previous;
    else if (midi.selectedInput && devices.some(device => device.id === midi.selectedInput)) {
      select.value = midi.selectedInput;
    }
  },
  onActivity: event => {
    if (event.type === "noteon") {
      granular.noteOn(event.note, event.velocity, event.channel);
      updatePitchReadout(event.note);
      document.getElementById("midiLed").classList.add("on");
      document.getElementById("midiStatus").textContent = `NOTE ${event.note} / VELOCITY ${event.velocity}`;
    } else if (event.type === "noteoff") {
      granular.noteOff(event.note, event.channel);
      document.getElementById("midiStatus").textContent = "MIDI ПОДКЛЮЧЁН";
    }
  },
  onControlChange: event => handleControlChange(event)
});

const params = [
  {id:"pitch",name:"ВЫСОТА ТОНА",value:50,unit:"hz"},
  {id:"noise",name:"NOISE",value:0},
  {id:"texture",name:"ТЕКСТУРА",value:50},
  {id:"attack",name:"АТАКА",value:20,slider:true},
  {id:"sustain",name:"УДЕРЖАНИЕ",value:70,slider:true},
  {id:"release",name:"ЗАТУХАНИЕ",value:40,slider:true}
];
const fx = [
  {id:"reverb",name:"РЕВЕРБЕРАЦИЯ",value:35},
  {id:"delay",name:"ЗАДЕРЖКА",value:20},
  {id:"modulation",name:"МОДУЛЯЦИЯ",value:25}
];
const values = {};
const MIDI_MAP_STORAGE_KEY = "ambient-midi-cc-map-v1";
const midiParameterNames = {
 pitch: "ВЫСОТА ТОНА",
 noise: "NOISE",
 texture: "ТЕКСТУРА",
 attack: "АТАКА",
 sustain: "УДЕРЖАНИЕ",
 release: "ЗАТУХАНИЕ",
 reverb: "РЕВЕРБЕРАЦИЯ",
 delay: "ЗАДЕРЖКА",
 modulation: "МОДУЛЯЦИЯ",
 parameter_volume: "ГРОМКОСТЬ FX",
 masterVolume: "МАСТЕР-ГРОМКОСТЬ"
};
let mappingSequence = 0;
let midiMappings = loadMidiMappings();
let midiLearnTarget = null;
// Per-mapping pickup state prevents a hardware control from jumping a software value.
const midiPickupState = {};
function loadMidiMappings() {
 try {
   const parsed = JSON.parse(localStorage.getItem(MIDI_MAP_STORAGE_KEY) || "{}");
   if (!parsed || typeof parsed !== "object") return {};
   const migrated = {};
   for (const [key, raw] of Object.entries(parsed)) {
     const entries = Array.isArray(raw) ? raw : [raw];
     migrated[key] = entries.filter(Boolean).map(item => {
       const target = typeof item === "string" ? item : item.target;
       return {
         id: item && typeof item === "object" && item.id ? String(item.id) : `legacy-${++mappingSequence}`,
         target: target === "resonance" ? "noise" : target,
         min: Math.max(0, Math.min(target === "parameter_volume" ? 200 : 100, Number(item?.min ?? 0))),
         max: Math.max(0, Math.min(target === "parameter_volume" ? 200 : 100, Number(item?.max ?? (target === "parameter_volume" ? 200 : 100)))),
         invert: Boolean(item?.invert)
       };
     }).filter(item => midiParameterNames[item.target]);
     if (!migrated[key].length) delete migrated[key];
   }
   return migrated;
 } catch (_) { return {}; }
}
function saveMidiMappings() {
 try { localStorage.setItem(MIDI_MAP_STORAGE_KEY, JSON.stringify(midiMappings)); }
 catch (error) { console.warn("AMBIENT: не удалось сохранить MIDI mapping", error); }
}
function renderMidiMappings() {
 const list = document.getElementById("midiMappingList");
 if (!list) return;
 const rows = [];
 Object.entries(midiMappings).forEach(([key, mappings]) => {
   const [channel, cc] = key.split(":");
   mappings.forEach(mapping => {
     const maxValue = mapping.target === "parameter_volume" ? 200 : 100;
     const name = midiParameterNames[mapping.target] || mapping.target;
     rows.push(`<div class="midi-map-item" data-map-id="${mapping.id}">
       <div class="midi-map-title"><span>${name}</span><span>CH ${channel} · CC ${cc}</span></div>
       <label class="midi-map-limit">MIN <input type="number" min="0" max="${maxValue}" value="${mapping.min}" data-map-field="min" data-map-id="${mapping.id}"></label>
       <label class="midi-map-limit">MAX <input type="number" min="0" max="${maxValue}" value="${mapping.max}" data-map-field="max" data-map-id="${mapping.id}"></label>
       <label class="midi-map-invert"><input type="checkbox" data-map-field="invert" data-map-id="${mapping.id}" ${mapping.invert ? "checked" : ""}> INV</label>
       <button type="button" class="midi-map-remove" data-map-id="${mapping.id}" aria-label="Удалить назначение ${name}">×</button>
     </div>`);
   });
 });
 list.innerHTML = rows.length ? rows.join("") : '<div class="midi-map-empty">НАЗНАЧЕНИЙ ПОКА НЕТ</div>';
 const count = rows.length;
 const countNode = document.getElementById("midiMappingCount");
 if (countNode) countNode.textContent = String(count);
}
function beginMidiLearn() {
 const target = document.getElementById("midiLearnParameter").value;
 if (!midi.selectedInput) {
   document.getElementById("midiLearnStatus").textContent = "СНАЧАЛА ПОДКЛЮЧИТЕ MIDI";
   return;
 }
 midiLearnTarget = target;
 document.getElementById("midiLearnButton").classList.add("learning");
 document.getElementById("midiLearnButton").textContent = "ОЖИДАНИЕ CC…";
 document.getElementById("midiLearnStatus").textContent = `ДВИГАЙТЕ РЕГУЛЯТОР ДЛЯ: ${midiParameterNames[target]}`;
}
function getTargetValue(target) {
 return target === "masterVolume"
   ? Number(document.getElementById("masterVolume")?.value ?? 0)
   : target === "parameter_volume"
     ? Number(document.getElementById("parameter_volume")?.dataset.value ?? 100)
     : Number(document.querySelector(`.knob[data-param="${target}"]`)?.dataset.value
       ?? document.querySelector(`.range[data-param="${target}"]`)?.value ?? 0);
}
function applyMappedValue(target, value) {
 const mappedValue = Math.round(value);
 if (target === "masterVolume") {
   const master = document.getElementById("masterVolume");
   master.value = mappedValue;
   master.style.setProperty("--pct", `${mappedValue}%`);
   document.getElementById("masterValue").textContent = `${mappedValue}%`;
   audio.setParameter("masterVolume", mappedValue);
 } else setValue(target, mappedValue);
}
function updateMidiActivity(event, activeCount = 0) {
 const readout = document.getElementById("midiCCActivity");
 const meter = document.getElementById("midiCCMeter");
 if (readout) readout.textContent = `CH ${event.channel} · CC ${event.controller} · ${event.value}${activeCount ? ` · ${activeCount} MAP` : ""}`;
 if (meter) meter.style.setProperty("--cc-level", `${(event.value / 127) * 100}%`);
}
function handleControlChange(event) {
 const key = `${event.channel}:${event.controller}`;
 if (midiLearnTarget) {
   const max = midiLearnTarget === "parameter_volume" ? 200 : 100;
   const mapping = { id: `map-${Date.now()}-${++mappingSequence}`, target: midiLearnTarget, min: 0, max, invert: false };
   if (!midiMappings[key]) midiMappings[key] = [];
   // Re-learning the same destination from the same source replaces that link only.
   midiMappings[key] = midiMappings[key].filter(existing => existing.target !== midiLearnTarget);
   midiMappings[key].push(mapping);
   midiPickupState[mapping.id] = { previous: event.value, acquired: false };
   saveMidiMappings();
   const targetName = midiParameterNames[midiLearnTarget] || midiLearnTarget;
   midiLearnTarget = null;
   document.getElementById("midiLearnButton").classList.remove("learning");
   document.getElementById("midiLearnButton").textContent = "MIDI LEARN";
   document.getElementById("midiLearnStatus").textContent = `ДОБАВЛЕНО: ${targetName} · CH ${event.channel} / CC ${event.controller}`;
   renderMidiMappings();
 }
 const mappings = midiMappings[key] || [];
 updateMidiActivity(event, mappings.length);
 if (!mappings.length) return;
 mappings.forEach(mapping => {
   const maxValue = mapping.target === "parameter_volume" ? 200 : 100;
   const low = Math.max(0, Math.min(maxValue, Number(mapping.min)));
   const high = Math.max(low, Math.min(maxValue, Number(mapping.max)));
   const currentValue = Math.max(low, Math.min(high, getTargetValue(mapping.target)));
   const span = high - low;
   const normalizedCurrent = span === 0 ? 0 : (currentValue - low) / span;
   const targetCC = mapping.invert ? 127 - normalizedCurrent * 127 : normalizedCurrent * 127;
   const pickup = midiPickupState[mapping.id] || (midiPickupState[mapping.id] = { previous: null, acquired: false });
   const previous = pickup.previous;
   const crossed = previous !== null && ((previous <= targetCC && event.value >= targetCC) || (previous >= targetCC && event.value <= targetCC));
   const closeEnough = Math.abs(event.value - targetCC) <= 1;
   if (!pickup.acquired && (crossed || closeEnough)) pickup.acquired = true;
   pickup.previous = event.value;
   if (!pickup.acquired) return;
   const normalized = event.value / 127;
   const mapped = mapping.invert ? high - normalized * span : low + normalized * span;
   applyMappedValue(mapping.target, mapped);
 });
}
let displayedMidiNote = 69; // A4 reference until a played note is received.

function midiFrequency(note, pitchPercent = Number(document.querySelector('.knob[data-param="pitch"]')?.dataset.value ?? 50)) {
 const cents = (pitchPercent - 50) * 2;
 return 440 * Math.pow(2, ((Number(note) - 69) / 12) + cents / 1200);
}
function updatePitchReadout(note = displayedMidiNote) {
 displayedMidiNote = Number(note);
 const pitchKnob = document.querySelector('.knob[data-param="pitch"]');
 const pitchPercent = Number(pitchKnob?.dataset.value ?? 50);
 const hz = midiFrequency(displayedMidiNote, pitchPercent);
 const value = document.getElementById("pitch-value");
 if (value) value.textContent = `${hz.toFixed(hz >= 100 ? 1 : 2)} Hz`;
}
function resonanceQ(value) {
 const normalized = Math.max(0, Math.min(100, Number(value))) / 100;
 return 0.5 + 23.5 * Math.pow(normalized, 2);
}

function knobMarkup(p){
 const display = p.unit === "hz" ? "440.0 Hz" : `${p.value}%`;
 const hint = p.unit === "hz" ? "ТОЧНАЯ НАСТРОЙКА ±100 CENT" : "0 — 100%";
 return `<div class="control-card"><div class="control-top"><span class="control-name">${p.name}</span><span class="value" id="${p.id}-value">${display}</span></div>
 <div class="knob-area"><div class="knob" data-param="${p.id}" data-value="${p.value}" role="slider" tabindex="0" aria-label="${p.name}" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${p.value}">
 <svg viewBox="0 0 64 64"><circle class="track" cx="32" cy="32" r="25" stroke-dasharray="118 40" transform="rotate(135 32 32)"/><circle class="progress" cx="32" cy="32" r="25" stroke-dasharray="${p.value*1.18} 158" transform="rotate(135 32 32)"/><line class="pointer" x1="32" y1="32" x2="32" y2="13" transform="rotate(${-135+p.value*2.7} 32 32)"/></svg></div></div><span class="control-hint">${hint}</span></div>`;
}
function sliderMarkup(p){
 return `<div class="control-card slider-card"><div class="control-top"><span class="control-name">${p.name}</span><span class="value" id="${p.id}-value">${p.value}%</span></div><div class="slider-body"><input class="range" data-param="${p.id}" type="range" min="0" max="100" value="${p.value}" style="--pct:${p.value}%" aria-label="${p.name}"><span class="control-hint">0 — 100%</span></div></div>`;
}

document.getElementById("knobGrid").innerHTML=params.map(p=>p.slider?sliderMarkup(p):knobMarkup(p)).join("");
document.getElementById("fxGrid").innerHTML=fx.map(knobMarkup).join("");
updatePitchReadout(69);


function setValue(id,v){
 const maxValue = id === "parameter_volume" ? 200 : 100;
 v=Math.max(0,Math.min(maxValue,Math.round(Number(v))));
 values[id]=v;
 const val=document.getElementById(id+"-value");
 if(val) {
   if(id==="pitch") val.textContent = `${midiFrequency(displayedMidiNote, v).toFixed(midiFrequency(displayedMidiNote, v) >= 100 ? 1 : 2)} Hz`;
   else val.textContent=v+"%";
 }
 const k=document.querySelector(`.knob[data-param="${id}"]`);
 if(k){
   k.dataset.value=v;
   k.setAttribute("aria-valuenow",v);
   const c=k.querySelector(".progress");
   const l=k.querySelector(".pointer");
   const ratio = v / maxValue;
   c.setAttribute("stroke-dasharray",`${ratio*118} 158`);
   l.setAttribute("transform",`rotate(${-135+ratio*270} 32 32)`);
 }
 const r=document.querySelector(`.range[data-param="${id}"]`);
 if(r){r.value=v;r.style.setProperty("--pct",v+"%");}
 audio.setParameter(id,v);
 if(id==="parameter_volume") {
   document.getElementById("parameter_volume_value").textContent=v+"%";
   audio.setParameter("parameter_volume",v);
 }
}

let drag=null,lastY=0;
document.addEventListener("pointerdown",e=>{
 const k=e.target.closest(".knob");
 if(!k)return;
 drag=k;lastY=e.clientY;
});
document.addEventListener("pointermove",e=>{
 if(!drag)return;
 const id=drag.dataset.param;
 setValue(id,Number(drag.dataset.value)-(e.clientY-lastY)*.65);
 lastY=e.clientY;
});
document.addEventListener("pointerup",()=>drag=null);
document.addEventListener("pointercancel",()=>drag=null);

// Double-click reset: ordinary sound/effect controls -> 0%;
// independent per-effect Gain -> 100% (unity gain).
document.addEventListener("dblclick",e=>{
 const knob=e.target.closest(".knob");
 if(!knob)return;
 const id=knob.dataset.param;
 if(!id)return;
 e.preventDefault();
 if(id==="parameter_volume") {
   setValue("parameter_volume",100);
 } else {
   setValue(id,0);
 }
});

document.addEventListener("keydown",e=>{
 const k=e.target.closest(".knob");
 if(!k||!["ArrowUp","ArrowDown","ArrowRight","ArrowLeft","Home","End"].includes(e.key))return;
 e.preventDefault();
 let v=Number(k.dataset.value);
 if(e.key==="Home")v=0;
 else if(e.key==="End")v=(k.dataset.param==="parameter_volume"?200:100);
 else v+=["ArrowUp","ArrowRight"].includes(e.key)?1:-1;
 setValue(k.dataset.param,v);
});

document.querySelectorAll(".range").forEach(r=>r.addEventListener("input",()=>{
 r.style.setProperty("--pct",r.value+"%");
 if(r.dataset.param)setValue(r.dataset.param,r.value);
 else {
   document.getElementById("masterValue").textContent=r.value+"%";
   audio.setParameter("masterVolume",r.value);
 }
}));

function refreshParameterVolumeControl() {
 const selected = document.getElementById("parameterSelect").value.toLowerCase();
 audio.setSelectedParameter(selected);
 const current = audio.getParameterVolume(selected);
 const knob = document.querySelector('.knob[data-param="parameter_volume"]');
 const ratio = current / 200;
 knob.dataset.value = current;
 knob.setAttribute("aria-valuenow", current);
 knob.querySelector(".progress").setAttribute("stroke-dasharray", `${ratio*118} 158`);
 knob.querySelector(".pointer").setAttribute("transform", `rotate(${-135+ratio*270} 32 32)`);
 document.getElementById("parameter_volume_value").textContent = current + "%";
 document.querySelector(".parameter-volume .eyebrow").textContent = "ВЫБРАН: " + document.getElementById("parameterSelect").selectedOptions[0].textContent;
}

// Oscillator 2 controls. Kept outside the MIDI Learn system in this first pass.
const osc2Enabled = document.getElementById("osc2Enabled");
const osc2Waveform = document.getElementById("osc2Waveform");
const osc2Level = document.getElementById("osc2Level");
const osc2Octave = document.getElementById("osc2Octave");
const osc2Detune = document.getElementById("osc2Detune");
osc2Enabled.addEventListener("change", () => audio.setOsc2("enabled", osc2Enabled.checked));
osc2Waveform.addEventListener("change", () => audio.setOsc2("waveform", osc2Waveform.value));
osc2Level.addEventListener("input", () => {
  osc2Level.style.setProperty("--pct", `${osc2Level.value}%`);
  document.getElementById("osc2LevelValue").textContent = `${osc2Level.value}%`;
  audio.setOsc2("level", osc2Level.value);
});
osc2Octave.addEventListener("input", () => {
  osc2Octave.style.setProperty("--pct", `${((Number(osc2Octave.value) + 2) / 4) * 100}%`);
  document.getElementById("osc2OctaveValue").textContent = Number(osc2Octave.value) > 0 ? `+${osc2Octave.value}` : osc2Octave.value;
  audio.setOsc2("octave", osc2Octave.value);
});
osc2Detune.addEventListener("input", () => {
  osc2Detune.style.setProperty("--pct", `${((Number(osc2Detune.value) + 100) / 200) * 100}%`);
  document.getElementById("osc2DetuneValue").textContent = `${osc2Detune.value} CENT`;
  audio.setOsc2("detune", osc2Detune.value);
});

refreshParameterVolumeControl();
renderMidiMappings();

document.getElementById("parameterSelect").addEventListener("change",refreshParameterVolumeControl);

document.getElementById("midiLearnButton").addEventListener("click", beginMidiLearn);
document.getElementById("midiClearMappings").addEventListener("click", () => {
 midiMappings = {};
 Object.keys(midiPickupState).forEach(key => delete midiPickupState[key]);
 saveMidiMappings();
 midiLearnTarget = null;
 document.getElementById("midiLearnButton").classList.remove("learning");
 document.getElementById("midiLearnButton").textContent = "MIDI LEARN";
 document.getElementById("midiLearnStatus").textContent = "ВСЕ НАЗНАЧЕНИЯ УДАЛЕНЫ";
 renderMidiMappings();
});
document.getElementById("midiMappingList").addEventListener("click", event => {
 const button = event.target.closest("[data-map-id].midi-map-remove");
 if (!button) return;
 const id = button.dataset.mapId;
 Object.entries(midiMappings).forEach(([key, mappings]) => {
   midiMappings[key] = mappings.filter(mapping => mapping.id !== id);
   if (!midiMappings[key].length) delete midiMappings[key];
 });
 delete midiPickupState[id];
 saveMidiMappings();
 renderMidiMappings();
});
document.getElementById("midiMappingList").addEventListener("change", event => {
 const field = event.target.dataset.mapField;
 const id = event.target.dataset.mapId;
 if (!field || !id) return;
 Object.values(midiMappings).flat().forEach(mapping => {
   if (mapping.id !== id) return;
   if (field === "invert") mapping.invert = event.target.checked;
   else {
     const maxValue = mapping.target === "parameter_volume" ? 200 : 100;
     const value = Math.max(0, Math.min(maxValue, Number(event.target.value) || 0));
     mapping[field] = value;
     if (mapping.min > mapping.max) mapping[field === "min" ? "max" : "min"] = value;
   }
 });
 saveMidiMappings();
 renderMidiMappings();
});

const mappingPanel = document.getElementById("midiMappingPanel");
const mappingToggle = document.getElementById("midiMappingToggle");
const MAPPING_PANEL_KEY = "ambient-midi-mapping-panel-hidden-v1";
function setMappingPanelHidden(hidden) {
 mappingPanel.hidden = hidden;
 mappingToggle.setAttribute("aria-expanded", String(!hidden));
 mappingToggle.textContent = hidden ? "ПОКАЗАТЬ" : "СКРЫТЬ";
 try { localStorage.setItem(MAPPING_PANEL_KEY, hidden ? "1" : "0"); } catch (_) {}
}
let mappingPanelHidden = false;
try { mappingPanelHidden = localStorage.getItem(MAPPING_PANEL_KEY) === "1"; } catch (_) {}
setMappingPanelHidden(mappingPanelHidden);
mappingToggle.addEventListener("click", () => setMappingPanelHidden(!mappingPanel.hidden));

let waveType="sine";
document.querySelectorAll(".wave-type").forEach(b=>b.addEventListener("click",()=>{
 document.querySelectorAll(".wave-type").forEach(x=>x.classList.remove("active"));
 b.classList.add("active");
 waveType=b.dataset.wave;
 audio.setWaveform(waveType);
 document.getElementById("waveLabel").textContent=waveType.toUpperCase()+" WAVE";
}));

function setMidiIndicator(on){
 document.getElementById("midiLed").classList.toggle("on",on);
 document.getElementById("midiStatus").textContent=on?"ЗВУК АКТИВЕН":"ОЖИДАНИЕ СИГНАЛА";
}

const midiConnectButton = document.getElementById("midiConnect");
const midiDeviceSelect = document.getElementById("midiDevice");

midiConnectButton.addEventListener("click", async () => {
  if (midi.selectedInput) {
    midi.disconnect();
    return;
  }

  midiConnectButton.disabled = true;
  try {
    const devices = await midi.connect();
    if (devices.length === 1) {
      midiDeviceSelect.value = devices[0].id;
    }
  } catch (error) {
    console.error("AMBIENT MIDI:", error);
  } finally {
    midiConnectButton.disabled = false;
  }
});

midiDeviceSelect.addEventListener("change", () => {
  if (midiDeviceSelect.value) {
    if (!midi.access) {
      document.getElementById("midiStatus").textContent = "НАЖМИТЕ ПОДКЛЮЧИТЬ";
      return;
    }
    midi.selectInput(midiDeviceSelect.value);
  }
});

// Granular sampler controls. This module is deliberately separate from the stable synth engine.
const granularFile = document.getElementById("granularFile");
const granularFileName = document.getElementById("granularFileName");
const granularStatus = document.getElementById("granularStatus");
const granularStartButton = document.getElementById("granularStart");
const granularCanvas = document.getElementById("granularWave");
const granularCtx = granularCanvas.getContext("2d");
let granularMode = "continuous";

granularFile.addEventListener("change", async () => {
  const file = granularFile.files && granularFile.files[0];
  if (!file) return;
  granularStatus.textContent = "ДЕКОДИРОВАНИЕ АУДИО...";
  try {
    const info = await granular.loadFile(file);
    granularFileName.textContent = info.name;
    granularStatus.textContent = `${info.duration.toFixed(2)} S / ${info.sampleRate} HZ / ${info.channels} CH`;
    granularStartButton.disabled = granularMode !== "continuous";
    drawGranularWave();
  } catch (error) {
    console.error("AMBIENT granular load:", error);
    granularStatus.textContent = "НЕ УДАЛОСЬ ПРОЧИТАТЬ ФАЙЛ — ПРОВЕРЬТЕ ФОРМАТ";
  }
});

document.querySelectorAll(".granular-mode").forEach(button => button.addEventListener("click", () => {
  granularMode = button.dataset.mode;
  granular.setMode(granularMode);
  document.querySelectorAll(".granular-mode").forEach(item => item.classList.toggle("active", item === button));
  granularStartButton.disabled = !granular.buffer || granularMode !== "continuous";
  granularStartButton.textContent = "ЗАПУСТИТЬ";
  granularStartButton.classList.remove("running");
  const touchPanel = document.getElementById("granularTouchPanel");
  touchPanel.hidden = granularMode !== "touch";
  granularStatus.textContent = granularMode === "continuous"
    ? (granular.buffer ? "CONTINUOUS — НЕПРЕРЫВНАЯ ГЕНЕРАЦИЯ ГРАНУЛ" : "ЗАГРУЗИТЕ АУДИОФАЙЛ")
    : (granular.buffer ? "TOUCH PAD — КАСАНИЕ ЗАПУСКАЕТ ЗВУК, ОТПУСКАНИЕ ОСТАНАВЛИВАЕТ НОВЫЕ ГРАНУЛЫ" : "ЗАГРУЗИТЕ АУДИОФАЙЛ, ЗАТЕМ ИСПОЛЬЗУЙТЕ TOUCH PAD");
}));

// Direct multitouch control for Android. No MIDI emulation is involved.
const touchpad = document.getElementById("granularTouchpad");
const touchCursor = document.getElementById("touchpadCursor");
const touchReadout = document.getElementById("touchpadReadout");
const touchHint = document.getElementById("touchpadHint");
const activeTouches = new Map();
let primaryTouchId = null;
let previousTouchPoint = null;
let previousTouchTime = 0;

function setTouchParameter(name, value) {
  granular.setParameter(name, value);
  const outputId = name === "grainSize" ? "grainSizeValue" : name === "density" ? "grainDensityValue" : name === "position" ? "grainPositionValue" : name === "pitch" ? "grainPitchValue" : null;
  const output = outputId && document.getElementById(outputId);
  if (output) output.textContent = name === "grainSize" ? `${Math.round(value)} ms` : name === "density" ? `${Math.round(value)} / s` : name === "pitch" ? `${Math.round(value)} st` : `${Math.round(value)}%`;
  const control = document.querySelector(`[data-grain="${name}"]`);
  if (control) {
    control.value = value;
    control.style.setProperty("--pct", `${(value - Number(control.min)) / (Number(control.max) - Number(control.min)) * 100}%`);
  }
}

function updatePrimaryTouch(point, now) {
  const rect = touchpad.getBoundingClientRect();
  const x = Math.max(0, Math.min(1, (point.x - rect.left) / rect.width));
  const y = Math.max(0, Math.min(1, (point.y - rect.top) / rect.height));
  setTouchParameter("position", x * 100);
  setTouchParameter("grainSize", 15 + (1 - y) * 485);
  touchCursor.style.left = `${x * 100}%`;
  touchCursor.style.top = `${y * 100}%`;
  if (previousTouchPoint && now > previousTouchTime) {
    const dx = point.x - previousTouchPoint.x;
    const dy = point.y - previousTouchPoint.y;
    const speed = Math.hypot(dx, dy) / ((now - previousTouchTime) / 1000);
    setTouchParameter("density", 2 + Math.min(58, speed / 20));
  }
  previousTouchPoint = point;
  previousTouchTime = now;
  touchReadout.textContent = `X ${Math.round(x * 100)}% · Y ${Math.round(15 + (1-y)*485)} ms`;
}

touchpad.addEventListener("pointerdown", async event => {
  if (granularMode !== "touch" || !granular.buffer) return;
  event.preventDefault();
  touchpad.setPointerCapture(event.pointerId);
  const point = { x: event.clientX, y: event.clientY };
  activeTouches.set(event.pointerId, point);
  if (primaryTouchId === null) {
    primaryTouchId = event.pointerId;
    previousTouchPoint = null;
    await granular.startTouch();
    touchHint.hidden = true;
    touchHint.textContent = "";
    touchpad.classList.add("active");
    updatePrimaryTouch(point, performance.now());
    granularStatus.textContent = "TOUCH ACTIVE — ПЕРЕМЕЩАЙТЕ ПАЛЕЦ ДЛЯ ИЗМЕНЕНИЯ ЗВУКА";
  } else {
    const rect = touchpad.getBoundingClientRect();
    const y = Math.max(0, Math.min(1, (event.clientY - rect.top) / rect.height));
    setTouchParameter("pitch", (0.5 - y) * 48);
    touchReadout.textContent += ` · PITCH ${Math.round((0.5-y)*48)} st`;
  }
});

touchpad.addEventListener("pointermove", event => {
  if (!activeTouches.has(event.pointerId)) return;
  event.preventDefault();
  const point = { x: event.clientX, y: event.clientY };
  activeTouches.set(event.pointerId, point);
  if (event.pointerId === primaryTouchId) updatePrimaryTouch(point, performance.now());
  else {
    const rect = touchpad.getBoundingClientRect();
    const y = Math.max(0, Math.min(1, (event.clientY - rect.top) / rect.height));
    setTouchParameter("pitch", (0.5 - y) * 48);
    touchReadout.textContent = `PITCH ${Math.round((0.5-y)*48)} st`;
  }
});

function releaseTouch(event) {
  if (!activeTouches.has(event.pointerId)) return;
  activeTouches.delete(event.pointerId);
  if (event.pointerId === primaryTouchId) {
    primaryTouchId = activeTouches.size ? activeTouches.keys().next().value : null;
    previousTouchPoint = null;
  }
  if (activeTouches.size === 0) {
    granular.stopTouch();
    touchpad.classList.remove("active");
    touchHint.hidden = false;
    touchHint.textContent = "КОСНИТЕСЬ И ДВИГАЙТЕ ПАЛЕЦ";
    granularStatus.textContent = "TOUCH RELEASED — НОВЫЕ ГРАНУЛЫ ОСТАНОВЛЕНЫ";
  }
}
touchpad.addEventListener("pointerup", releaseTouch);
touchpad.addEventListener("pointercancel", releaseTouch);

granularStartButton.addEventListener("click", () => {
  if (!granular.buffer || granularMode !== "continuous") return;
  if (granular.continuous) {
    granular.stopContinuous();
    granularStartButton.textContent = "ЗАПУСТИТЬ";
    granularStartButton.classList.remove("running");
    granularStatus.textContent = "CONTINUOUS / STOPPED";
  } else {
    granular.startContinuous();
    granularStartButton.textContent = "ОСТАНОВИТЬ";
    granularStartButton.classList.add("running");
    granularStatus.textContent = "CONTINUOUS / RUNNING";
  }
});

document.querySelectorAll("[data-grain]").forEach(control => {
  const key = control.dataset.grain;
  const update = () => {
    const value = control.type === "checkbox" ? control.checked : Number(control.value);
    granular.setParameter(key, value);
    if (control.type !== "checkbox") {
      control.style.setProperty("--pct", `${(Number(control.value) - Number(control.min)) / (Number(control.max) - Number(control.min)) * 100}%`);
      const output = document.getElementById(`grain${key[0].toUpperCase()}${key.slice(1)}Value`);
      if (output) {
        const suffix = key === "grainSize" ? " ms" : key === "density" ? " / s" : key === "pitch" || key === "pitchRandom" ? " st" : "%";
        output.textContent = `${value}${suffix}`;
      }
    }
  };
  control.addEventListener("input", update);
  control.addEventListener("change", update);
});

const regionStart = document.getElementById("grainRegionStart");
const regionEnd = document.getElementById("grainRegionEnd");
regionStart.addEventListener("input", () => {
  if (Number(regionStart.value) >= Number(regionEnd.value)) regionStart.value = Number(regionEnd.value) - 1;
  granular.setParameter("regionStart", Number(regionStart.value));
  regionStart.style.setProperty("--pct", `${regionStart.value}%`);
});
regionEnd.addEventListener("input", () => {
  if (Number(regionEnd.value) <= Number(regionStart.value)) regionEnd.value = Number(regionStart.value) + 1;
  granular.setParameter("regionEnd", Number(regionEnd.value));
  regionEnd.style.setProperty("--pct", `${regionEnd.value}%`);
});

function drawGranularWave() {
  const rect = granularCanvas.getBoundingClientRect();
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  if (granularCanvas.width !== Math.round(rect.width * dpr) || granularCanvas.height !== Math.round(rect.height * dpr)) {
    granularCanvas.width = Math.round(rect.width * dpr);
    granularCanvas.height = Math.round(rect.height * dpr);
  }
  granularCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
  const w = rect.width, h = rect.height;
  granularCtx.clearRect(0, 0, w, h);
  const data = granular.getWaveform();
  if (!data) return;
  const start = Number(regionStart.value) / 100;
  const end = Number(regionEnd.value) / 100;
  granularCtx.fillStyle = "rgba(229,229,229,.055)";
  granularCtx.fillRect(start * w, 0, (end - start) * w, h);
  granularCtx.beginPath();
  granularCtx.moveTo(0, h / 2);
  granularCtx.lineTo(w, h / 2);
  granularCtx.strokeStyle = "rgba(229,229,229,.16)";
  granularCtx.stroke();
  granularCtx.beginPath();
  for (let i = 0; i < data.length; i++) {
    const x = i / (data.length - 1) * w;
    const y = h / 2 - data[i] * h * .43;
    if (i === 0) granularCtx.moveTo(x, y); else granularCtx.lineTo(x, y);
  }
  granularCtx.strokeStyle = "#e5e5e5";
  granularCtx.lineWidth = 1.2;
  granularCtx.stroke();
}

const canvas=document.getElementById("wave");
const ctx=canvas.getContext("2d");
function drawWave(){
 const rect=canvas.getBoundingClientRect();
 const dpr=Math.min(window.devicePixelRatio||1,2);
 if(canvas.width!==Math.round(rect.width*dpr)||canvas.height!==Math.round(rect.height*dpr)){
   canvas.width=Math.round(rect.width*dpr);
   canvas.height=Math.round(rect.height*dpr);
 }
 ctx.setTransform(dpr,0,0,dpr,0,0);
 const w=rect.width,h=rect.height,mid=h/2;
 ctx.clearRect(0,0,w,h);
 ctx.beginPath(); ctx.moveTo(0,mid); ctx.lineTo(w,mid);
 ctx.strokeStyle="rgba(229,229,229,.10)"; ctx.lineWidth=1; ctx.stroke();
 const data=audio.getWaveformData();
 if(data){
   ctx.beginPath(); const step=data.length/w;
   for(let x=0;x<=w;x++){
     const index=Math.min(data.length-1,Math.floor(x*step));
     const sample=(data[index]-128)/128;
     const y=mid-sample*(h*.43);
     if(x===0)ctx.moveTo(x,y);else ctx.lineTo(x,y);
   }
   ctx.strokeStyle="#e5e5e5"; ctx.lineWidth=1.45; ctx.lineJoin="round"; ctx.stroke();
 }
 requestAnimationFrame(drawWave);
}
drawWave();

window.addEventListener("blur",()=>{
 audio.panic();
 granular.panic();
 if (granularStartButton) {
   granularStartButton.textContent = "ЗАПУСТИТЬ";
   granularStartButton.classList.remove("running");
 }
 setMidiIndicator(false);
 document.getElementById("engineStatus").textContent="AUDIO ENGINE / READY";
 document.getElementById("engineLed").classList.remove("active");
});
