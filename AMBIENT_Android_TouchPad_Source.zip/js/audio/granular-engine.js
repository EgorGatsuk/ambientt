// AMBIENT Granular Engine — isolated from the oscillator voice engine.
export class AmbientGranularEngine {
  constructor(audio) {
    this.audio = audio;
    this.buffer = null;
    this.fileName = "";
    this.mode = "continuous";
    this.touchActive = false;
    this.params = {
      grainSize: 120, density: 12, position: 50, spray: 12,
      pitch: 0, pitchRandom: 0, envelope: 50, spread: 35,
      level: 70, reverse: false, freeze: false, jitter: 0,
      regionStart: 0, regionEnd: 100
    };
    this.timer = null;
    this.continuous = false;
    this.noteVoices = new Map();
    this.nextId = 1;
    this.maxActiveGrains = 96;
    this.activeGrains = new Set();
  }

  async loadFile(file) {
    if (!file) return;
    await this.audio.ensureStarted();
    const bytes = await file.arrayBuffer();
    const decoded = await this.audio.context.decodeAudioData(bytes.slice(0));
    this.buffer = decoded;
    this.fileName = file.name;
    this._updateTimer();
    return { name: file.name, duration: decoded.duration, sampleRate: decoded.sampleRate, channels: decoded.numberOfChannels };
  }

  setMode(mode) {
    if (!["continuous", "midi", "touch"].includes(mode)) return;
    this.mode = mode;
    if (mode !== "continuous") this.stopContinuous();
    if (mode !== "touch") this.stopTouch();
    this._updateTimer();
  }

  setParameter(name, value) {
    if (!(name in this.params)) return;
    if (typeof this.params[name] === "boolean") this.params[name] = Boolean(value);
    else this.params[name] = Number(value);
    if (name === "regionStart" && this.params.regionStart > this.params.regionEnd - 1) this.params.regionStart = this.params.regionEnd - 1;
    if (name === "regionEnd" && this.params.regionEnd < this.params.regionStart + 1) this.params.regionEnd = this.params.regionStart + 1;
    this._updateTimer();
  }

  startContinuous() {
    if (!this.buffer || this.mode !== "continuous") return;
    this.continuous = true;
    this._updateTimer();
  }

  stopContinuous() {
    this.continuous = false;
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  _updateTimer() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    if (this.mode === "continuous" && this.continuous && this.buffer) {
      const interval = Math.max(8, 1000 / Math.max(1, this.params.density));
      this.timer = setInterval(() => this._spawnGrain(null), interval);
    } else if (this.mode === "touch" && this.touchActive && this.buffer) {
      const interval = Math.max(8, 1000 / Math.max(1, this.params.density));
      this.timer = setInterval(() => this._spawnGrain(null), interval);
    }
  }

  async startTouch() {
    if (!this.buffer || this.mode !== "touch") return;
    const token = ++this.touchStartToken;
    await this.audio.ensureStarted();
    if (token !== this.touchStartToken || this.mode !== "touch") return;
    this.touchActive = true;
    this._updateTimer();
  }

  stopTouch() {
    this.touchStartToken++;
    this.touchActive = false;
    if (this.mode === "touch" && this.timer) clearInterval(this.timer);
    if (this.mode === "touch") this.timer = null;
  }

  noteOn(note, velocity = 100, channel = 1) {
    if (this.mode !== "midi" || !this.buffer) return null;
    const id = this.nextId++;
    const voice = { id, note: Number(note), velocity: Math.max(0, Math.min(127, velocity)) / 127, channel, held: true, timer: null };
    this.noteVoices.set(id, voice);
    const interval = Math.max(8, 1000 / Math.max(1, this.params.density));
    this._spawnGrain(voice);
    voice.timer = setInterval(() => {
      if (voice.held) this._spawnGrain(voice);
    }, interval);
    return id;
  }

  noteOff(note, channel = 1) {
    const matches = [...this.noteVoices.values()].filter(v => v.note === Number(note) && v.channel === channel && v.held);
    const voice = matches[matches.length - 1];
    if (!voice) return;
    voice.held = false;
    if (voice.timer) clearInterval(voice.timer);
    voice.timer = null;
    // Let already scheduled grains finish naturally; prevent new grains.
    this.noteVoices.delete(voice.id);
  }

  panic() {
    this.stopContinuous();
    this.stopTouch();
    for (const voice of this.noteVoices.values()) if (voice.timer) clearInterval(voice.timer);
    this.noteVoices.clear();
  }

  _spawnGrain(voice) {
    const ctx = this.audio.context;
    const buffer = this.buffer;
    if (!ctx || !buffer || this.activeGrains.size >= this.maxActiveGrains) return;
    const p = this.params;
    const size = Math.max(0.015, Math.min(2, p.grainSize / 1000));
    const start = p.regionStart / 100;
    const end = p.regionEnd / 100;
    const span = Math.max(0.01, end - start);
    let normalized = p.freeze ? p.position / 100 : p.position / 100 + (Math.random() - 0.5) * 2 * p.spray / 100;
    normalized = start + Math.max(0, Math.min(1, normalized)) * span;
    if (p.jitter) normalized += (Math.random() - 0.5) * (p.jitter / 100) * span;
    normalized = Math.max(start, Math.min(end - 0.001, normalized));
    const offset = normalized * buffer.duration;
    const duration = Math.max(0.01, Math.min(size, buffer.duration - offset));
    const semitones = p.pitch + (Math.random() - 0.5) * p.pitchRandom;
    const midiOffset = voice ? (voice.note - 60) : 0;
    const rate = Math.pow(2, (semitones + midiOffset) / 12) * (p.reverse ? -1 : 1);
    const safeRate = Math.max(0.125, Math.min(8, Math.abs(rate)));
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.playbackRate.value = safeRate;
    if (p.reverse) {
      const reverseBuffer = this._getReverseBuffer();
      source.buffer = reverseBuffer;
    }
    const gain = ctx.createGain();
    const pan = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
    const now = ctx.currentTime + 0.006;
    const fade = Math.max(0.003, Math.min(size * 0.45, size * p.envelope / 220));
    const velocity = voice ? voice.velocity : 1;
    const amplitude = (p.level / 100) * velocity / Math.sqrt(Math.max(1, p.density / 8));
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.linearRampToValueAtTime(Math.max(0.0001, amplitude), now + fade);
    gain.gain.setValueAtTime(Math.max(0.0001, amplitude), now + Math.max(fade, size - fade));
    gain.gain.linearRampToValueAtTime(0.0001, now + size);
    if (pan) {
      pan.pan.value = (Math.random() * 2 - 1) * p.spread / 100;
      source.connect(gain); gain.connect(pan);
      this._route(pan);
    } else { source.connect(gain); this._route(gain); }
    const grain = { source, gain, pan };
    this.activeGrains.add(grain);
    source.onended = () => {
      this.activeGrains.delete(grain);
      try { source.disconnect(); gain.disconnect(); if (pan) pan.disconnect(); } catch (_) {}
    };
    try { source.start(now, p.reverse ? Math.max(0, buffer.duration - offset - duration) : offset, duration); }
    catch (error) { this.activeGrains.delete(grain); try { source.disconnect(); gain.disconnect(); } catch (_) {} }
  }

  _route(node) {
    const a = this.audio;
    node.connect(a.dryGain);
    node.connect(a.reverbInput);
    node.connect(a.delayInput);
    node.connect(a.textureShaper);
  }

  _getReverseBuffer() {
    if (!this.buffer) return null;
    if (this._reverseSource === this.buffer && this._reverseBuffer) return this._reverseBuffer;
    const ctx = this.audio.context;
    const reversed = ctx.createBuffer(this.buffer.numberOfChannels, this.buffer.length, this.buffer.sampleRate);
    for (let c = 0; c < this.buffer.numberOfChannels; c++) {
      const src = this.buffer.getChannelData(c);
      const dst = reversed.getChannelData(c);
      for (let i = 0, j = src.length - 1; i < src.length; i++, j--) dst[i] = src[j];
    }
    this._reverseSource = this.buffer;
    this._reverseBuffer = reversed;
    return reversed;
  }

  getWaveform(samples = 512) {
    if (!this.buffer) return null;
    const channel = this.buffer.getChannelData(0);
    const result = new Float32Array(samples);
    const step = channel.length / samples;
    for (let i = 0; i < samples; i++) {
      const start = Math.floor(i * step);
      const end = Math.max(start + 1, Math.floor((i + 1) * step));
      let peak = 0;
      for (let j = start; j < end; j++) peak = Math.max(peak, Math.abs(channel[j]));
      result[i] = peak;
    }
    return result;
  }
}
