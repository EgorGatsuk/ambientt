export class AmbientAudioEngine {
  constructor() {
    this.context = null;
    this.master = null;
    this.analyser = null;
    this.analyserData = null;
    this.sumBus = null;
    this.dryGain = null;
    this.voices = new Map();
    this.nextVoiceId = 1;
    this.maxVoices = 16;

    this.waveform = "sine";
    this.osc2 = { enabled: false, waveform: "triangle", level: 35, octave: 0, detune: 0 };
    this.pitch = 50; // 50 = zero cents; 0..100 = -100..+100 cents
    this.noise = 0;
    this.attack = 20;
    this.sustain = 70;
    this.release = 40;
    this.masterVolume = 80;

    this.fx = { reverb: 35, delay: 20, texture: 50, modulation: 25 };
    // Independent post-effect gain per FX block. 100% = unity gain; >100% amplifies.
    this.fxOutput = { reverb: 1, delay: 1, texture: 1, modulation: 1, noise: 1 };
    this.fxOutputPercent = { reverb: 100, delay: 100, texture: 100, modulation: 100, noise: 100 };
    this.selectedParameter = "reverb";

    this.noiseBuffer = null;

    this.reverbInput = null;
    this.reverb = null;
    this.reverbWet = null;
    this.delayInput = null;
    this.delay = null;
    this.delayFeedback = null;
    this.delayWet = null;
    this.textureShaper = null;
    this.textureWet = null;
    this.lfo = null;
    this.lfoDepth = null;
    this.lfoStarted = false;
  }

  async ensureStarted() {
    if (!this.context) {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (!AudioContextClass) throw new Error("Этот браузер не поддерживает Web Audio API.");

      this.context = new AudioContextClass();
      this.master = this.context.createGain();
      this.master.gain.value = this.masterVolume / 100;

      // Analyze the final post-FX, post-master signal sent to the output.
      this.analyser = this.context.createAnalyser();
      this.analyser.fftSize = 2048;
      this.analyser.smoothingTimeConstant = 0.72;
      this.analyserData = new Uint8Array(this.analyser.fftSize);

      this.sumBus = this.context.createGain();
      this.dryGain = this.context.createGain();
      this.dryGain.gain.value = 1;
      this.dryGain.connect(this.sumBus);

      this.createReverb();
      this.createNoiseBuffer();
      this.createDelay();
      this.createTexture();
      this.createModulation();

      this.sumBus.connect(this.master);
      this.master.connect(this.analyser);
      this.analyser.connect(this.context.destination);
      this.applyAllFx();
    }

    if (this.context.state === "suspended") await this.context.resume();
  }

  createReverb() {
    const ctx = this.context;
    this.reverbInput = ctx.createGain();
    this.reverb = ctx.createConvolver();
    this.reverbWet = ctx.createGain();
    const sampleRate = ctx.sampleRate;
    const seconds = 5.5;
    const length = Math.floor(sampleRate * seconds);
    const impulse = ctx.createBuffer(2, length, sampleRate);

    for (let channel = 0; channel < 2; channel++) {
      const data = impulse.getChannelData(channel);
      for (let i = 0; i < length; i++) {
        const t = i / length;
        const envelope = Math.pow(1 - t, 3.8);
        data[i] = (Math.random() * 2 - 1) * envelope;
      }
    }

    this.reverb.buffer = impulse;
    this.reverbInput.connect(this.reverb);
    this.reverb.connect(this.reverbWet);
    this.reverbWet.connect(this.sumBus);
  }

  createNoiseBuffer() {
    const length = this.context.sampleRate * 2;
    this.noiseBuffer = this.context.createBuffer(1, length, this.context.sampleRate);
    const data = this.noiseBuffer.getChannelData(0);
    for (let i = 0; i < length; i++) data[i] = Math.random() * 2 - 1;
  }

  createDelay() {
    const ctx = this.context;
    this.delayInput = ctx.createGain();
    this.delay = ctx.createDelay(2.0);
    this.delayFeedback = ctx.createGain();
    this.delayWet = ctx.createGain();

    this.delayInput.connect(this.delay);
    this.delay.connect(this.delayWet);
    this.delayWet.connect(this.sumBus);
    this.delay.connect(this.delayFeedback);
    this.delayFeedback.connect(this.delay);
  }

  createTexture() {
    const ctx = this.context;
    this.textureShaper = ctx.createWaveShaper();
    this.textureShaper.oversample = "4x";
    this.textureWet = ctx.createGain();
    this.textureShaper.connect(this.textureWet);
    this.textureWet.connect(this.sumBus);
    this.updateTextureCurve();
  }

  createModulation() {
    const ctx = this.context;
    this.lfo = ctx.createOscillator();
    this.lfo.type = "sine";
    this.lfo.frequency.value = 0.35;
    this.lfoDepth = ctx.createGain();
    this.lfo.connect(this.lfoDepth);
    this.lfo.start();
    this.lfoStarted = true;
    this.updateModulation();
  }

  updateTextureCurve() {
    if (!this.textureShaper) return;
    const amount = this.fx.texture / 100;
    const drive = 1 + amount * 24;
    const samples = 2048;
    const curve = new Float32Array(samples);
    for (let i = 0; i < samples; i++) {
      const x = (i * 2) / (samples - 1) - 1;
      curve[i] = Math.tanh(x * drive) / Math.tanh(drive);
    }
    this.textureShaper.curve = curve;
  }

  applyAllFx() {
    if (!this.context) return;
    const now = this.context.currentTime;
    const smooth = (param, value, time = 0.04) => param.setTargetAtTime(value, now, time);

    if (this.reverbWet) {
      smooth(this.reverbWet.gain, (this.fx.reverb / 100) * this.fxOutput.reverb);
    }

    if (this.delay) {
      const amount = this.fx.delay / 100;
      smooth(this.delay.delayTime, 0.12 + amount * 0.68);
      smooth(this.delayFeedback.gain, Math.min(0.72, amount * 0.72));
      smooth(this.delayWet.gain, amount * 0.75 * this.fxOutput.delay);
    }

    if (this.textureWet) {
      smooth(this.textureWet.gain, (this.fx.texture / 100) * 0.42 * this.fxOutput.texture);
      this.updateTextureCurve();
    }

    this.updateNoiseLevels();
    this.updateModulation();
  }

  updateModulation() {
    if (!this.context || !this.lfoDepth) return;
    const amount = this.fx.modulation / 100;
    const rate = 0.15 + amount * 4.0;
    this.lfo.frequency.setTargetAtTime(rate, this.context.currentTime, 0.05);
    this.lfoDepth.gain.setTargetAtTime(
      amount * 18 * this.fxOutput.modulation,
      this.context.currentTime,
      0.05
    );
  }

  setSelectedParameter(id) {
    const allowed = ["reverb", "delay", "texture", "modulation", "noise"];
    if (!allowed.includes(id)) return;
    this.selectedParameter = id;
  }

  getParameterVolume(id = this.selectedParameter) {
    return this.fxOutputPercent[id] ?? 100;
  }

  setParameterVolume(id, value) {
    const allowed = ["reverb", "delay", "texture", "modulation", "noise"];
    if (!allowed.includes(id)) return;
    const percent = Math.max(0, Math.min(200, Math.round(Number(value))));
    this.fxOutputPercent[id] = percent;
    this.fxOutput[id] = percent / 100;
    this.applyAllFx();
  }

  setWaveform(type) {
    const mapped = type === "saw" ? "sawtooth" : type;
    if (!["sine", "sawtooth", "square", "triangle"].includes(mapped)) return;
    this.waveform = mapped;
    for (const voice of this.voices.values()) {
      if (!voice.stopping) voice.oscillator.type = mapped;
    }
  }

  setOsc2(id, value) {
    if (id === "enabled") this.osc2.enabled = Boolean(value);
    else if (id === "waveform") {
      const mapped = value === "saw" ? "sawtooth" : value;
      if (!["sine", "sawtooth", "square", "triangle"].includes(mapped)) return;
      this.osc2.waveform = mapped;
    } else if (id === "level") this.osc2.level = Math.max(0, Math.min(100, Number(value)));
    else if (id === "octave") this.osc2.octave = Math.max(-2, Math.min(2, Math.round(Number(value))));
    else if (id === "detune") this.osc2.detune = Math.max(-100, Math.min(100, Number(value)));
    else return;

    if (!this.context) return;
    const now = this.context.currentTime;
    for (const voice of this.voices.values()) {
      if (voice.stopping || !voice.oscillator2 || !voice.oscillator2Gain) continue;
      voice.oscillator2.type = this.osc2.waveform;
      voice.oscillator2.frequency.setTargetAtTime(this.midiToFrequency(voice.note) * Math.pow(2, this.osc2.octave), now, 0.025);
      voice.oscillator2.detune.setTargetAtTime(this.osc2.detune, now, 0.025);
      voice.oscillator2Gain.gain.setTargetAtTime(this.osc2.enabled ? this.osc2.level / 100 : 0, now, 0.025);
    }
  }

  setParameter(id, value) {
    const normalized = Math.max(0, Math.min(100, Number(value))) / 100;

    if (id === "pitch") {
      this.pitch = normalized * 100;
      this.updateAllFrequencies();
    } else if (id === "noise") {
      this.noise = normalized * 100;
      this.updateNoiseLevels();
    } else if (id === "attack") {
      this.attack = normalized * 100;
    } else if (id === "sustain") {
      this.sustain = normalized * 100;
      if (this.context) {
        const now = this.context.currentTime;
        for (const voice of this.voices.values()) {
          if (voice.isHeld && !voice.stopping) {
            voice.envelope.gain.setTargetAtTime(this.sustainToGain(this.sustain) * voice.velocity, now, 0.03);
          }
        }
      }
    } else if (id === "release") {
      this.release = normalized * 100;
    } else if (id === "masterVolume") {
      this.masterVolume = normalized * 100;
      if (this.master && this.context) this.master.gain.setTargetAtTime(normalized, this.context.currentTime, 0.025);
    } else if (["reverb", "delay", "texture", "modulation"].includes(id)) {
      this.fx[id] = normalized * 100;
      this.applyAllFx();
    } else if (id === "parameter_volume") {
      this.setParameterVolume(this.selectedParameter, Number(value));
    }
  }

  attackToSeconds(value) { return 0.005 * Math.pow(800, value / 100); }
  releaseToSeconds(value) { return 0.02 * Math.pow(300, value / 100); }
  sustainToGain(value) { return value / 100; }
  // Fine tuning: the center position is concert pitch; full travel is +/-100 cents.
  pitchToCents(value = this.pitch) {
    return (Math.max(0, Math.min(100, Number(value))) - 50) * 2;
  }

  midiToFrequency(note) {
    const cents = this.pitchToCents();
    return 440 * Math.pow(2, ((Number(note) - 69) / 12) + (cents / 1200));
  }

  updateNoiseLevels() {
    if (!this.context) return;
    const gain = (this.noise / 100) * 0.35 * this.fxOutput.noise;
    const now = this.context.currentTime;
    for (const voice of this.voices.values()) {
      if (voice.noiseGain && !voice.stopping) {
        voice.noiseGain.gain.setTargetAtTime(gain, now, 0.025);
      }
    }
  }

  updateAllFrequencies() {
    if (!this.context) return;
    const now = this.context.currentTime;
    for (const voice of this.voices.values()) {
      if (!voice.stopping) {
        voice.oscillator.frequency.setTargetAtTime(this.midiToFrequency(voice.note), now, 0.025);
        if (voice.oscillator2) voice.oscillator2.frequency.setTargetAtTime(this.midiToFrequency(voice.note) * Math.pow(2, this.osc2.octave), now, 0.025);
      }
    }
  }

  chooseVoiceToSteal() {
    const active = [...this.voices.values()];
    if (!active.length) return null;
    const released = active.filter(voice => !voice.isHeld);
    const candidates = released.length ? released : active;
    return candidates.reduce((oldest, voice) => voice.startedAt < oldest.startedAt ? voice : oldest);
  }

  stopVoice(voice, fadeSeconds = 0.012) {
    if (!voice || voice.stopping || !this.context) return;
    voice.stopping = true;
    const now = this.context.currentTime;
    const gain = voice.envelope.gain;
    try {
      gain.cancelScheduledValues(now);
      if (typeof gain.cancelAndHoldAtTime === "function") gain.cancelAndHoldAtTime(now);
      else gain.setValueAtTime(Math.max(0.0001, gain.value), now);
      gain.setTargetAtTime(0.0001, now, Math.max(0.002, fadeSeconds / 4));
      voice.oscillator.stop(now + fadeSeconds);
      voice.noiseSource.stop(now + fadeSeconds);
      voice.oscillator2.stop(now + fadeSeconds);
    } catch (_) {
      try { voice.oscillator.stop(now + fadeSeconds); } catch (_) {}
      try { voice.oscillator2.stop(now + fadeSeconds); } catch (_) {}
      try { voice.noiseSource.stop(now + fadeSeconds); } catch (_) {}
    }
  }

  async noteOn(note, velocity = 100) {
    await this.ensureStarted();

    if (this.voices.size >= this.maxVoices) {
      const stolen = this.chooseVoiceToSteal();
      if (stolen) {
        this.voices.delete(stolen.id);
        this.stopVoice(stolen, 0.018);
      }
    }

    const now = this.context.currentTime;
    const oscillator = this.context.createOscillator();
    const oscillator2 = this.context.createOscillator();
    const oscillator2Gain = this.context.createGain();
    const envelope = this.context.createGain();
    const modulationGain = this.context.createGain();
    const noiseSource = this.context.createBufferSource();
    const noiseGain = this.context.createGain();

    oscillator.type = this.waveform;
    oscillator2.type = this.osc2.waveform;
    oscillator2.frequency.setValueAtTime(this.midiToFrequency(note) * Math.pow(2, this.osc2.octave), now);
    oscillator2.detune.setValueAtTime(this.osc2.detune, now);
    oscillator2Gain.gain.setValueAtTime(this.osc2.enabled ? this.osc2.level / 100 : 0, now);
    noiseSource.buffer = this.noiseBuffer;
    noiseSource.loop = true;
    noiseGain.gain.setValueAtTime((this.noise / 100) * 0.35 * this.fxOutput.noise, now);
    oscillator.frequency.setValueAtTime(this.midiToFrequency(note), now);

    const normalizedVelocity = Math.max(0, Math.min(1, velocity / 127));
    const peak = Math.max(0.0001, this.sustainToGain(this.sustain) * normalizedVelocity);

    envelope.gain.setValueAtTime(0.0001, now);
    // Oscillator and white-noise source are mixed directly into the voice envelope.
    oscillator.connect(envelope);
    oscillator2.connect(oscillator2Gain);
    oscillator2Gain.connect(envelope);
    noiseSource.connect(noiseGain);
    noiseGain.connect(envelope);

    // Parallel dry and effect sends.
    envelope.connect(this.dryGain);
    envelope.connect(this.reverbInput);
    envelope.connect(this.delayInput);
    envelope.connect(this.textureShaper);

    // Per-voice LFO depth connection; the shared LFO modulates oscillator detune.
    this.lfoDepth.connect(modulationGain);
    modulationGain.connect(oscillator.detune);
    modulationGain.gain.value = 1;

    const id = this.nextVoiceId++;
    const voice = {
      id, note: Number(note), velocity: normalizedVelocity,
      oscillator, oscillator2, oscillator2Gain, noiseSource, noiseGain, envelope, modulationGain,
      startedAt: now, isHeld: true, stopping: false
    };
    this.voices.set(id, voice);

    oscillator.onended = () => {
      this.voices.delete(id);
      try {
        oscillator.disconnect(); oscillator2.disconnect(); oscillator2Gain.disconnect(); noiseSource.disconnect(); noiseGain.disconnect();
        envelope.disconnect();
        modulationGain.disconnect(); this.lfoDepth.disconnect(modulationGain);
      } catch (_) {}
    };

    oscillator.start(now);
    oscillator2.start(now);
    noiseSource.start(now);
    envelope.gain.linearRampToValueAtTime(peak, now + this.attackToSeconds(this.attack));
    return id;
  }

  noteOff(note, voiceId = null) {
    if (!this.context) return;
    const matches = [...this.voices.values()]
      .filter(voice => voice.note === Number(note) && voice.isHeld && !voice.stopping &&
        (voiceId === null || voice.id === voiceId))
      .sort((a, b) => b.startedAt - a.startedAt);
    const voice = matches[0];
    if (!voice) return;

    voice.isHeld = false;
    const now = this.context.currentTime;
    const releaseSeconds = this.releaseToSeconds(this.release);
    const gain = voice.envelope.gain;
    try {
      gain.cancelScheduledValues(now);
      if (typeof gain.cancelAndHoldAtTime === "function") gain.cancelAndHoldAtTime(now);
      else gain.setValueAtTime(Math.max(0.0001, gain.value), now);
      gain.linearRampToValueAtTime(0.0001, now + releaseSeconds);
      voice.oscillator.stop(now + releaseSeconds + 0.035);
      voice.noiseSource.stop(now + releaseSeconds + 0.035);
      voice.oscillator2.stop(now + releaseSeconds + 0.035);
    } catch (_) { this.stopVoice(voice, 0.02); }
  }

  panic() {
    if (!this.context) return;
    for (const voice of this.voices.values()) this.stopVoice(voice, 0.015);
    this.voices.clear();
  }

  getWaveformData() {
    if (!this.analyser || !this.analyserData) return null;
    this.analyser.getByteTimeDomainData(this.analyserData);
    return this.analyserData;
  }

  get activeVoiceCount() {
    return [...this.voices.values()].filter(voice => !voice.stopping).length;
  }
}
