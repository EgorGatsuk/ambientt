export class AmbientMidiEngine {
  constructor(audioEngine, callbacks = {}) {
    this.audio = audioEngine;
    this.onStatus = callbacks.onStatus || (() => {});
    this.onActivity = callbacks.onActivity || (() => {});
    this.onDevices = callbacks.onDevices || (() => {});
    this.onControlChange = callbacks.onControlChange || (() => {});
    this.access = null;
    this.selectedInput = null;
    this.activeNotes = new Map();
    this.isSupported = !!navigator.requestMIDIAccess;
  }

  async connect() {
    if (!this.isSupported) {
      this.onStatus("БРАУЗЕР НЕ ПОДДЕРЖИВАЕТ WEB MIDI", "error");
      throw new Error("Web MIDI API недоступен. Используйте актуальный Chrome или Edge.");
    }

    try {
      this.access = await navigator.requestMIDIAccess({ sysex: false });
      this.access.onstatechange = () => this.refreshDevices();
      this.refreshDevices();

      const inputs = [...this.access.inputs.values()];
      if (inputs.length === 1) {
        this.selectInput(inputs[0].id);
      } else if (inputs.length === 0) {
        this.onStatus("MIDI-УСТРОЙСТВО НЕ НАЙДЕНО", "waiting");
      } else {
        this.onStatus("ВЫБЕРИТЕ MIDI-УСТРОЙСТВО", "waiting");
      }
      return inputs;
    } catch (error) {
      const message = error && error.name === "NotAllowedError"
        ? "ДОСТУП К MIDI ЗАПРЕЩЁН"
        : "НЕ УДАЛОСЬ ПОДКЛЮЧИТЬ MIDI";
      this.onStatus(message, "error");
      throw error;
    }
  }

  refreshDevices() {
    if (!this.access) return;
    const inputs = [...this.access.inputs.values()];
    this.onDevices(inputs.map(input => ({
      id: input.id,
      name: input.name || input.manufacturer || "MIDI Input",
      manufacturer: input.manufacturer || ""
    })));

    if (this.selectedInput && !this.access.inputs.has(this.selectedInput)) {
      this.releaseAllNotes();
      this.selectedInput = null;
      this.onStatus("MIDI-УСТРОЙСТВО ОТКЛЮЧЕНО", "waiting");
    }
  }

  selectInput(id) {
    if (!this.access) return;

    if (this.selectedInput) {
      const previous = this.access.inputs.get(this.selectedInput);
      if (previous) {
        previous.onmidimessage = null;
        previous.onstatechange = null;
      }
    }

    this.releaseAllNotes();
    const input = this.access.inputs.get(id);
    if (!input) {
      this.selectedInput = null;
      this.onStatus("MIDI-УСТРОЙСТВО НЕ НАЙДЕНО", "error");
      return;
    }

    this.selectedInput = id;
    input.onmidimessage = event => this.handleMessage(event);
    input.onstatechange = () => this.refreshDevices();
    this.onStatus(`ПОДКЛЮЧЕНО: ${input.name || "MIDI INPUT"}`, "connected");
  }

  handleMessage(event) {
    const data = event.data;
    if (!data || data.length < 2) return;

    const status = data[0] & 0xF0;
    const channel = (data[0] & 0x0F) + 1;
    const data1 = data[1];
    const data2 = data.length > 2 ? data[2] : 0;

    // Process Control Change independently of the note lifecycle.
    // CC must remain live while one or more notes are held.
    if (status === 0xB0) {
      const message = {
        type: "cc",
        controller: data1,
        value: Math.max(0, Math.min(127, data2)),
        channel
      };
      this.onActivity(message);
      this.onControlChange(message);
      return;
    }

    // Note On
    if (status === 0x90 && data2 > 0) {
      const note = data1;
      const velocity = data2;
      const key = `${channel}:${note}`;

      const token = { voiceId: null, released: false };
      if (!this.activeNotes.has(key)) this.activeNotes.set(key, []);
      this.activeNotes.get(key).push(token);

      this.audio.noteOn(note, velocity).then(voiceId => {
        token.voiceId = voiceId;
        // If Note Off arrived before AudioContext finished starting, release now.
        if (token.released) this.audio.noteOff(note, voiceId);
        this.onActivity({ type: "noteon", note, velocity, channel });
      }).catch(error => {
        const stack = this.activeNotes.get(key);
        if (stack) {
          const index = stack.indexOf(token);
          if (index >= 0) stack.splice(index, 1);
          if (!stack.length) this.activeNotes.delete(key);
        }
        console.error("AMBIENT MIDI Note On:", error);
        this.onStatus("ОШИБКА ЗАПУСКА АУДИО", "error");
      });
      return;
    }

    // Note Off (0x80) and Note On with velocity 0.
    if (status === 0x80 || (status === 0x90 && data2 === 0)) {
      const note = data1;
      const key = `${channel}:${note}`;
      const stack = this.activeNotes.get(key);
      if (stack && stack.length) {
        const token = stack.shift();
        token.released = true;
        if (token.voiceId !== null) this.audio.noteOff(note, token.voiceId);
        if (!stack.length) this.activeNotes.delete(key);
      }
      this.onActivity({ type: "noteoff", note, channel });
      return;
    }

  }

  releaseAllNotes() {
    for (const [key, stack] of this.activeNotes.entries()) {
      const note = Number(key.split(":")[1]);
      for (const token of stack) {
        token.released = true;
        if (token.voiceId !== null) this.audio.noteOff(note, token.voiceId);
      }
    }
    this.activeNotes.clear();
  }

  disconnect() {
    this.releaseAllNotes();
    if (this.access && this.selectedInput) {
      const input = this.access.inputs.get(this.selectedInput);
      if (input) input.onmidimessage = null;
    }
    this.selectedInput = null;
    this.onStatus("MIDI ОТКЛЮЧЁН", "waiting");
  }
}
