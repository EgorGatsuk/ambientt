
const { app, BrowserWindow, session, shell } = require('electron');
const path = require('node:path');

app.setName('AMBIENT');

function isAmbientWindow(webContents) {
  if (!webContents || webContents.isDestroyed()) return false;
  return webContents.getURL().startsWith('file://');
}

function isMidiPermission(permission) {
  return permission === 'midi' || permission === 'midiSysex';
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1440,
    height: 960,
    minWidth: 1100,
    minHeight: 760,
    show: false,
    autoHideMenuBar: true,
    backgroundColor: '#171717',
    title: 'AMBIENT',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  win.once('ready-to-show', () => win.show());
  win.loadFile(path.join(__dirname, '..', 'index.html'));

  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('https://') || url.startsWith('http://')) {
      shell.openExternal(url);
    }
    return { action: 'deny' };
  });

  win.webContents.on('will-navigate', (event, url) => {
    if (url !== win.webContents.getURL()) event.preventDefault();
  });
}

app.whenReady().then(() => {
  const ses = session.defaultSession;

  ses.setPermissionCheckHandler(
    (webContents, permission) => {
      const allowed =
        isAmbientWindow(webContents) && isMidiPermission(permission);

      console.log('[AMBIENT permission check]', permission, allowed);
      return allowed;
    }
  );

  ses.setPermissionRequestHandler(
    (webContents, permission, callback) => {
      const allowed =
        isAmbientWindow(webContents) && isMidiPermission(permission);

      console.log('[AMBIENT permission request]', permission, allowed);
      callback(allowed);
    }
  );

  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
