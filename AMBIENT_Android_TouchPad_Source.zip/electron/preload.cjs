// Intentionally minimal preload. The renderer does not receive Node.js access.
