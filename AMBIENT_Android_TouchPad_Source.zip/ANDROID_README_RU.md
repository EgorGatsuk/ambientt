# AMBIENT Granular — Android-порт (preview)

Это отдельная Android Studio оболочка для существующего веб-аудиодвижка AMBIENT. Windows/Electron проект не заменяется.

## Что уже перенесено в Android-проект
- Исходные UI, Audio Engine, Granular Engine и параметры из версии 0.2.0.
- Адаптивная сенсорная компоновка для узких экранов.
- Вместо MIDI-подключения на смартфоне — XY Touch Pad для гранулярного движка.
- Android WebView оболочка с JavaScript, DOM storage и разрешённым воспроизведением аудио.
- Системный HTML file input используется для выбора аудиофайла через Android WebView.
- Отдельный applicationId `com.ambient.granular`.

## Важные ограничения preview
- На мобильном экране MIDI-панель скрыта: основной способ управления гранулятором — Touch Pad. Desktop/Electron MIDI-код оставлен в исходниках, но Android-порт от него не зависит.
- Touch Pad: X управляет Position, Y — Grain Size, скорость движения — Density, второй палец по вертикали — Pitch.
- APK не собран в этой среде: здесь отсутствуют Android SDK и Gradle. Нужна сборка в Android Studio с установленным SDK 35.
- Реальное качество аудио, задержка и воспроизведение на фоне требуют проверки на физическом устройстве.

## Сборка в Android Studio
1. Установить Android Studio и Android SDK Platform 35.
2. В корне проекта выполнить `npm install` (или `npm ci`, если lockfile присутствует).
3. Выполнить `npm run android:assets`.
4. Открыть папку `android` в Android Studio.
5. Дождаться Gradle Sync, затем Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK будет в `android/app/build/outputs/apk/debug/app-debug.apk`.

Параметры проекта: package `com.ambient.granular`, minSdk 26 (Android 8.0), targetSdk 35.
